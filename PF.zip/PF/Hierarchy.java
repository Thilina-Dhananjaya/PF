class Publication{
	
	private String title;
	private double price;
	
	
	public void getData(){
	
	
	}
	
	public void print(){
	
	
	}

}

class Hierarchy{
	
	public static void main(String[] args){
	
		
	
	
	
	}

}


