public abstract class ThreeDiamensional extends Shape{
	
	public abstract double getSurface();
	public abstract double getVolume();

}