public abstract class TwoDiamensional extends Shape{
	public abstract double getArea();
	public abstract double getCircumference();
}