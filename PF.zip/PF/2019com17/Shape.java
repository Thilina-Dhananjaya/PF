public abstract class Shape{
	public String shapeName ="Shape";
	public String toString(){
		return shapeName;
	}
}